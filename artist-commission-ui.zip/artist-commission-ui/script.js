// Mock Data (ready to be replaced by PHP/MySQL JSON endpoints in Backend phase)
const ARTISTS = [
  {
    name: "Elena Vance",
    handle: "@pastel_sky",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&h=300&fit=crop",
    bio: "2D Character Illustrator & Visual Development artist. Available for VTuber models, book covers, and game character sheets.",
    tags: ["Digital Arts", "Animation"]
  },
  {
    name: "Marcus Crow",
    handle: "@ink_wraith",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop",
    bio: "Traditional ink, manga linework, and dark fantasy concept artist with 5+ years of indie publishing experience.",
    tags: ["Fine Arts", "Digital Arts"]
  },
  {
    name: "Ren Takahashi",
    handle: "@crimson_ink",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&h=300&fit=crop",
    bio: "Action storyboarder, frame-by-frame 2D animator, and comic colorist. Fast turnaround for commercial trailers.",
    tags: ["Animation", "Videography"]
  },
  {
    name: "Sora Lin",
    handle: "@lofi_sora",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&h=300&fit=crop",
    bio: "Original game OST composer, sound designer, and acoustic session producer.",
    tags: ["Music", "Videography"]
  }
];

const BANNERS = [
  "BANNER — Featured Commission Event & Artist Spotlight",
  "OPEN CALL — Indie Game Studios Seeking 2D Animators",
  "WORKSHOP — Pricing Your Art Commissions in 2026"
];

const messagesData = [
  {
    id: 1,
    sender: "Elena Vance (@pastel_sky)",
    text: "Hey! I can take your character commission starting this week.",
    time: "5m ago",
    unread: true
  }
];

const notificationsData = [
  {
    id: 1,
    text: "Your artwork was featured in Creations of the Week!",
    time: "1h ago",
    unread: true
  },
  {
    id: 2,
    text: "New commission brief posted under Digital Arts.",
    time: "3h ago",
    unread: true
  }
];

const DEFAULT_PROFILE = {
  username: "username",
  handle: "@Handle",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=240&h=240&fit=crop",
  banner: "",
  status: "Open for Commissions",
  rate: "$45 USD",
  bio: "Freelance character designer, 2D animator, and visual storyteller. Open for commercial game assets, album covers, and custom character commissions.",
  tags: ["Fine Arts", "Digital Arts", "Animation"],
  socials: {
    x: "https://x.com",
    fb: "https://facebook.com",
    dc: "https://discord.com",
    tg: "https://telegram.org"
  },
  prefs: {
    emailNotifs: true,
    directMsgs: true,
    publicCredits: true
  }
};

let bannerIdx = 0;
let matchIdx = 0;
let activeTag = null;

// Mobile Sidebar Drawer Controls
const mobileMenuBtn = document.getElementById("mobileMenuBtn");
const sidebarBackdrop = document.getElementById("sidebarBackdrop");
const sidebarEl = document.getElementById("sidebar");

function setMobileSidebar(open) {
  if (!sidebarEl || !sidebarBackdrop) return;
  sidebarEl.classList.toggle("mobile-open", open);
  sidebarBackdrop.classList.toggle("active", open);
}

if (mobileMenuBtn) {
  mobileMenuBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const isOpen = sidebarEl.classList.contains("mobile-open");
    setMobileSidebar(!isOpen);
  });
}

if (sidebarBackdrop) {
  sidebarBackdrop.addEventListener("click", () => setMobileSidebar(false));
}

// 1. Navigation & View Switcher
function switchView(viewName) {
  document.querySelectorAll(".view-section").forEach((sec) => sec.classList.remove("active"));
  const target = document.getElementById(`view-${viewName}`);
  if (target) target.classList.add("active");

  const activeKey = viewName === "search" ? "dashboard" : viewName;
  document.querySelectorAll(".nav-link[data-view]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.view === activeKey);
  });

  const icon = document.getElementById("toggleIcon");
  if (viewName === "talent") {
    sidebarEl.classList.add("collapsed");
    if (icon) icon.className = "ri-arrow-right-s-line";
  } else {
    sidebarEl.classList.remove("collapsed");
    if (icon) icon.className = "ri-arrow-left-s-line";
  }

  setMobileSidebar(false);
}

document.querySelectorAll(".nav-link[data-view]").forEach((btn) => {
  btn.addEventListener("click", () => {
    switchView(btn.dataset.view);
  });
});

// 2. Sidebar Collapse Button (< / >)
document.getElementById("sidebarToggle").addEventListener("click", () => {
  const icon = document.getElementById("toggleIcon");
  sidebarEl.classList.toggle("collapsed");
  icon.className = sidebarEl.classList.contains("collapsed")
    ? "ri-arrow-right-s-line"
    : "ri-arrow-left-s-line";
});

// 3. Topbar Messages & Notifications Popovers
const msgBtn = document.getElementById("msgBtn");
const notifBtn = document.getElementById("notifBtn");
const msgPopover = document.getElementById("msgPopover");
const notifPopover = document.getElementById("notifPopover");

function renderTopbarBadges() {
  const msgBadge = document.getElementById("msgBadge");
  const notifBadge = document.getElementById("notifBadge");

  const unreadMsgs = messagesData.filter((m) => m.unread).length;
  msgBadge.textContent = unreadMsgs;
  msgBadge.style.display = unreadMsgs > 0 ? "grid" : "none";

  const unreadNotifs = notificationsData.filter((n) => n.unread).length;
  notifBadge.textContent = unreadNotifs > 0 ? "!" : "";
  notifBadge.style.display = unreadNotifs > 0 ? "grid" : "none";
}

function renderPopovers() {
  const msgList = document.getElementById("msgList");
  const notifList = document.getElementById("notifList");

  msgList.innerHTML = messagesData.length
    ? messagesData
        .map(
          (m) => `
        <div class="popover-item ${m.unread ? "unread" : ""}" onclick="readMessage(${m.id})">
          <strong>${m.sender}</strong>
          <div>${m.text}</div>
          <div class="popover-meta"><span>${m.time}</span><span>${m.unread ? "Unread" : "Read"}</span></div>
        </div>`
        )
        .join("")
    : `<div class="popover-item">No messages yet.</div>`;

  notifList.innerHTML = notificationsData.length
    ? notificationsData
        .map(
          (n) => `
        <div class="popover-item ${n.unread ? "unread" : ""}" onclick="readNotification(${n.id})">
          <div>${n.text}</div>
          <div class="popover-meta"><span>${n.time}</span><span>${n.unread ? "New" : "Seen"}</span></div>
        </div>`
        )
        .join("")
    : `<div class="popover-item">All caught up!</div>`;

  renderTopbarBadges();
}

function readMessage(id) {
  const item = messagesData.find((m) => m.id === id);
  if (item) item.unread = false;
  renderPopovers();
}

function readNotification(id) {
  const item = notificationsData.find((n) => n.id === id);
  if (item) item.unread = false;
  renderPopovers();
}

function togglePopover(targetPopover, otherPopover) {
  otherPopover.classList.add("hidden");
  targetPopover.classList.toggle("hidden");
}

msgBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  togglePopover(msgPopover, notifPopover);
});

notifBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  togglePopover(notifPopover, msgPopover);
});

document.getElementById("markMsgReadBtn").addEventListener("click", () => {
  messagesData.forEach((m) => (m.unread = false));
  renderPopovers();
  showToast("All messages marked as read");
});

document.getElementById("clearNotifBtn").addEventListener("click", () => {
  notificationsData.length = 0;
  renderPopovers();
  showToast("Notifications cleared");
});

document.getElementById("quickMsgForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const input = document.getElementById("quickMsgInput");
  const text = input.value.trim();
  if (!text) return;

  messagesData.unshift({
    id: Date.now(),
    sender: "You → @pastel_sky",
    text,
    time: "Just now",
    unread: false
  });
  input.value = "";
  renderPopovers();
  showToast("Message sent!");
});

document.addEventListener("click", (e) => {
  if (!e.target.closest(".topbar-icons")) {
    msgPopover.classList.add("hidden");
    notifPopover.classList.add("hidden");
  }
});

// 4. Banner Carousel
function updateBanner(dir) {
  bannerIdx = (bannerIdx + dir + BANNERS.length) % BANNERS.length;
  document.querySelectorAll(".banner-slide").forEach((el) => {
    el.textContent = BANNERS[bannerIdx];
  });
}
document.getElementById("prevBanner").addEventListener("click", () => updateBanner(-1));
document.getElementById("nextBanner").addEventListener("click", () => updateBanner(1));

// 5. Render Search Results (Screen 2)
function renderResults(filterTag = null, query = "") {
  const list = document.getElementById("artistResultsList");
  const heading = document.getElementById("resultsHeading");
  const clearBtn = document.getElementById("clearFilterBtn");

  const filtered = ARTISTS.filter((a) => {
    const matchesTag = !filterTag || a.tags.includes(filterTag);
    const q = query.toLowerCase();
    const matchesQuery =
      !q ||
      a.name.toLowerCase().includes(q) ||
      a.handle.toLowerCase().includes(q) ||
      a.bio.toLowerCase().includes(q);
    return matchesTag && matchesQuery;
  });

  heading.textContent = filterTag
    ? `Results for "${filterTag}"`
    : query
    ? `Results for "${query}"`
    : "Results";
  clearBtn.style.display = filterTag || query ? "inline-block" : "none";

  list.innerHTML =
    filtered
      .map(
        (artist) => `
    <article class="result-item">
      <img src="${artist.avatar}" alt="${artist.name}" class="result-avatar" onclick="switchView('profile')" />
      <div class="result-body">
        <div class="result-title" onclick="switchView('profile')">
          ${artist.name} <span class="handle-text">${artist.handle}</span>
        </div>
        <div class="result-desc-box">${artist.bio}</div>
        <div class="result-tags">
          <span>Tags:</span>
          ${artist.tags.map((t) => `<span class="mini-blue-tag">${t}</span>`).join("")}
        </div>
      </div>
    </article>
  `
      )
      .join("") || `<p style="color:var(--text-muted)">No artists matched your filter.</p>`;
}

document.querySelectorAll(".tag-pill").forEach((btn) => {
  btn.addEventListener("click", () => {
    const tag = btn.dataset.tag;
    activeTag = activeTag === tag ? null : tag;

    document.querySelectorAll(".tag-pill").forEach((b) => {
      b.classList.toggle("active", b.dataset.tag === activeTag);
    });

    switchView("search");
    renderResults(activeTag, document.getElementById("searchInput").value);
  });
});

document.getElementById("clearFilterBtn").addEventListener("click", () => {
  activeTag = null;
  document.getElementById("searchInput").value = "";
  document.querySelectorAll(".tag-pill").forEach((b) => b.classList.remove("active"));
  renderResults();
});

document.getElementById("searchForm").addEventListener("submit", (e) => {
  e.preventDefault();
  switchView("search");
  renderResults(activeTag, document.getElementById("searchInput").value);
});

// 6. Profile Tabs & Follow Toggle
document.querySelectorAll("[data-ptab]").forEach((btn) => {
  btn.addEventListener("click", () => {
    const tab = btn.dataset.ptab;
    document.querySelectorAll("[data-ptab]").forEach((b) => {
      b.className = b.dataset.ptab === tab ? "btn-pill btn-sky active-tab" : "btn-pill btn-sky-outline";
    });
    document.getElementById("ptab-portfolio").classList.toggle("hidden", tab !== "portfolio");
    document.getElementById("ptab-commission").classList.toggle("hidden", tab !== "commission");
  });
});

document.getElementById("followBtn").addEventListener("click", function () {
  const following = this.textContent === "Following";
  this.textContent = following ? "Follow" : "Following";
  showToast(following ? "Unfollowed artist" : "Following artist!");
});

// 7. Talent Search Quick-Match Deck (Screen 4)
function renderMatchCard() {
  const artist = ARTISTS[matchIdx % ARTISTS.length];
  document.getElementById("matchAvatar").src = artist.avatar;
  document.getElementById("matchName").textContent = artist.name;
  document.getElementById("matchHandle").textContent = artist.handle;
  document.getElementById("matchBio").textContent = artist.bio;
  document.getElementById("matchTags").innerHTML = artist.tags
    .map((t) => `<span class="pill-muted">${t}</span>`)
    .join("");
}

document.getElementById("likeMatchBtn").addEventListener("click", () => {
  showToast(`Shortlisted ${ARTISTS[matchIdx % ARTISTS.length].handle}!`);
  matchIdx++;
  renderMatchCard();
});

document.getElementById("skipMatchBtn").addEventListener("click", () => {
  matchIdx++;
  renderMatchCard();
});

document.getElementById("msgMatchBtn").addEventListener("click", () => {
  openCommissionModal(`Inquiry for ${ARTISTS[matchIdx % ARTISTS.length].handle}`);
});

// 8. Expanded Settings Module (Live Image Previews, Tags, Socials, Preferences)
const avatarFileInput = document.getElementById("avatarFileInput");
const bannerFileInput = document.getElementById("bannerFileInput");
const settingsAvatarUrl = document.getElementById("settingsAvatarUrl");
const settingsBannerUrl = document.getElementById("settingsBannerUrl");
const settingsAvatarPreview = document.getElementById("settingsAvatarPreview");
const settingsBannerPreview = document.getElementById("settingsBannerPreview");

function previewBannerImage(url) {
  if (url && url.trim()) {
    settingsBannerPreview.style.backgroundImage = `url('${url.trim()}')`;
  } else {
    settingsBannerPreview.style.backgroundImage = "none";
  }
}

avatarFileInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    settingsAvatarPreview.src = ev.target.result;
    settingsAvatarUrl.value = ev.target.result;
  };
  reader.readAsDataURL(file);
});

bannerFileInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    settingsBannerUrl.value = ev.target.result;
    previewBannerImage(ev.target.result);
  };
  reader.readAsDataURL(file);
});

settingsAvatarUrl.addEventListener("input", (e) => {
  if (e.target.value.trim()) settingsAvatarPreview.src = e.target.value.trim();
});

settingsBannerUrl.addEventListener("input", (e) => {
  previewBannerImage(e.target.value);
});

document.querySelectorAll("#settingsTagPicker .tag-option").forEach((btn) => {
  btn.addEventListener("click", () => {
    btn.classList.toggle("active");
  });
});

function applyProfileSettings(data) {
  document.getElementById("topbarAvatar").src = data.avatar;
  document.getElementById("topbarUsername").textContent = data.username;

  document.getElementById("profileAvatar").src = data.avatar;
  const profileBanner = document.getElementById("profileBanner");
  profileBanner.style.backgroundImage = data.banner ? `url('${data.banner}')` : "none";

  document.getElementById("profileDisplayName").innerHTML = `${data.username} <span class="handle-text">${data.handle}</span>`;
  document.getElementById("profileBioText").textContent = data.bio;
  document.getElementById("profileStatusLabel").textContent = `${data.status} • Starting at ${data.rate}`;
  document.getElementById("commissionSlotsBadge").textContent = data.status;
  document.getElementById("tierStartingPrice").textContent = `${data.rate} • 3–5 Days`;

  const dot = document.getElementById("profileStatusDot");
  const statusLabel = document.getElementById("profileStatusLabel");
  if (data.status.includes("Closed")) {
    dot.style.background = "#71717a";
    statusLabel.style.color = "#a1a1aa";
  } else if (data.status.includes("Waitlist")) {
    dot.style.background = "#ff9f5a";
    statusLabel.style.color = "#ff9f5a";
  } else {
    dot.style.background = "#22c55e";
    statusLabel.style.color = "#22c55e";
  }

  document.getElementById("profileTagsRow").innerHTML = data.tags
    .map((t) => `<span class="tag-orange">${t}</span>`)
    .join("");

  document.getElementById("profileLinkX").href = data.socials.x || "#";
  document.getElementById("profileLinkFb").href = data.socials.fb || "#";
  document.getElementById("profileLinkDc").href = data.socials.dc || "#";
  document.getElementById("profileLinkTg").href = data.socials.tg || "#";

  document.getElementById("profileMsgBtn").style.display = data.prefs.directMsgs ? "inline-block" : "none";
  const creditsCard = document.getElementById("productionCreditsCard");
  const layoutGrid = document.getElementById("profileLayoutGrid");
  creditsCard.style.display = data.prefs.publicCredits ? "block" : "none";
  layoutGrid.classList.toggle("no-credits", !data.prefs.publicCredits);
}

document.getElementById("settingsForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const selectedTags = Array.from(document.querySelectorAll("#settingsTagPicker .tag-option.active")).map(
    (b) => b.dataset.stag
  );

  const updated = {
    username: document.getElementById("settingsUsername").value.trim() || "username",
    handle: document.getElementById("settingsHandle").value.trim() || "@Handle",
    avatar: settingsAvatarUrl.value.trim() || DEFAULT_PROFILE.avatar,
    banner: settingsBannerUrl.value.trim(),
    status: document.getElementById("settingsStatus").value,
    rate: document.getElementById("settingsRate").value.trim() || "$45 USD",
    bio: document.getElementById("settingsBio").value.trim(),
    tags: selectedTags.length ? selectedTags : ["Digital Arts"],
    socials: {
      x: document.getElementById("socialX").value.trim(),
      fb: document.getElementById("socialFb").value.trim(),
      dc: document.getElementById("socialDc").value.trim(),
      tg: document.getElementById("socialTg").value.trim()
    },
    prefs: {
      emailNotifs: document.getElementById("prefEmailNotifs").checked,
      directMsgs: document.getElementById("prefDirectMsgs").checked,
      publicCredits: document.getElementById("prefPublicCredits").checked
    }
  };

  applyProfileSettings(updated);
  showToast("All profile & account settings saved!");
});

document.getElementById("resetSettingsBtn").addEventListener("click", () => {
  document.getElementById("settingsUsername").value = DEFAULT_PROFILE.username;
  document.getElementById("settingsHandle").value = DEFAULT_PROFILE.handle;
  settingsAvatarUrl.value = DEFAULT_PROFILE.avatar;
  settingsAvatarPreview.src = DEFAULT_PROFILE.avatar;
  settingsBannerUrl.value = "";
  previewBannerImage("");
  document.getElementById("settingsStatus").value = DEFAULT_PROFILE.status;
  document.getElementById("settingsRate").value = DEFAULT_PROFILE.rate;
  document.getElementById("settingsBio").value = DEFAULT_PROFILE.bio;
  document.getElementById("prefEmailNotifs").checked = true;
  document.getElementById("prefDirectMsgs").checked = true;
  document.getElementById("prefPublicCredits").checked = true;

  document.querySelectorAll("#settingsTagPicker .tag-option").forEach((btn) => {
    btn.classList.toggle("active", DEFAULT_PROFILE.tags.includes(btn.dataset.stag));
  });

  applyProfileSettings(DEFAULT_PROFILE);
  showToast("Reset to default profile settings");
});

document.getElementById("logoutBtn").addEventListener("click", () => {
  document.getElementById("authToggleBtn").textContent = "Log in / Sign up";
  setMobileSidebar(false);
  showToast("You have been logged out.");
  switchView("dashboard");
});

// 9. Modals & Toast Helper
function openCommissionModal(prefill = "") {
  document.getElementById("commTitleInput").value = prefill;
  document.getElementById("commissionModal").classList.remove("hidden");
}

document.getElementById("openRequestModal").addEventListener("click", () => openCommissionModal());
document.getElementById("closeModalBtn").addEventListener("click", () => {
  document.getElementById("commissionModal").classList.add("hidden");
});

document.getElementById("commissionForm").addEventListener("submit", (e) => {
  e.preventDefault();
  document.getElementById("commissionModal").classList.add("hidden");
  showToast("Commission request sent to artist!");
});

document.getElementById("authToggleBtn").addEventListener("click", () => {
  document.getElementById("authModal").classList.remove("hidden");
});
document.getElementById("closeAuthModalBtn").addEventListener("click", () => {
  document.getElementById("authModal").classList.add("hidden");
});
document.getElementById("authForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("authUserInput").value.trim();
  if (name) {
    document.getElementById("topbarUsername").textContent = name;
    document.getElementById("settingsUsername").value = name;
    document.getElementById("authToggleBtn").textContent = "Create +";
  }
  document.getElementById("authModal").classList.add("hidden");
  showToast(`Welcome, ${name || "Artist"}!`);
});

function showToast(msg) {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}

// Initialize initial views
renderPopovers();
renderResults();
renderMatchCard();